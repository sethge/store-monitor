"""
Ops Logger Server v2.0 - 接收运营操作日志 + 结构化解析 + 改前值追踪
端口: 5500
"""
import json, sqlite3, os, re
from datetime import datetime
from flask import Flask, request, jsonify, render_template_string

app = Flask(__name__)

@app.after_request
def add_cors(response):
    response.headers["Access-Control-Allow-Origin"] = "*"
    response.headers["Access-Control-Allow-Headers"] = "Content-Type"
    response.headers["Access-Control-Allow-Methods"] = "GET, POST, OPTIONS"
    return response

DB_PATH = os.path.join(os.path.dirname(__file__), "ops_logs.db")
CONFIG_PATH = os.path.join(os.path.dirname(__file__), "config.json")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS logs (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            operator TEXT,
            timestamp TEXT,
            api_method TEXT,
            url TEXT,
            body_full TEXT,
            platform TEXT,
            shop_id TEXT,
            shop_name TEXT,
            tab_id INTEGER,
            item_id TEXT,
            item_name TEXT,
            action_type TEXT,
            action_detail TEXT,
            before_snapshot TEXT,
            received_at TEXT DEFAULT (datetime('now','localtime'))
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS food_cache (
            item_key TEXT PRIMARY KEY,
            item_id TEXT,
            shop_id TEXT,
            name TEXT,
            price REAL,
            specs TEXT,
            updated_at TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS shop_cache (
            shop_id TEXT PRIMARY KEY,
            shop_name TEXT,
            platform TEXT,
            updated_at TEXT
        )
    """)
    # Migrate old table if needed
    try:
        cols = [r[1] for r in conn.execute("PRAGMA table_info(logs)").fetchall()]
        migrations = {
            "item_id": "ALTER TABLE logs ADD COLUMN item_id TEXT",
            "item_name": "ALTER TABLE logs ADD COLUMN item_name TEXT",
            "action_type": "ALTER TABLE logs ADD COLUMN action_type TEXT",
            "action_detail": "ALTER TABLE logs ADD COLUMN action_detail TEXT",
            "before_snapshot": "ALTER TABLE logs ADD COLUMN before_snapshot TEXT",
            "body_full": "ALTER TABLE logs ADD COLUMN body_full TEXT",
            "shop_name": "ALTER TABLE logs ADD COLUMN shop_name TEXT",
        }
        for col, sql in migrations.items():
            if col not in cols:
                conn.execute(sql)
    except Exception as e:
        print(f"[migration] {e}")
    # food_snapshot table (created by init_snapshot.py, ensure it exists)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS food_snapshot (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            shop_id TEXT, shop_name TEXT, platform TEXT DEFAULT 'eleme',
            item_id TEXT, item_global_id TEXT, category_name TEXT,
            name TEXT, price REAL, image_url TEXT, specs TEXT,
            status TEXT, monthly_sales INTEGER DEFAULT 0,
            description TEXT, snapshot_at TEXT, raw_data TEXT
        )
    """)
    conn.commit()
    conn.close()

def load_config():
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH) as f:
            return json.load(f)
    return DEFAULT_CONFIG

def save_config(cfg):
    with open(CONFIG_PATH, "w") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)

DEFAULT_CONFIG = {
    "version": 1,
    "ignore_api_methods": [
        "HeadNoticeService.queryTabHeadNotice",
        "TraceService.trace",
        "PollingService.unprocessedOrders",
        "PollingService.abnormalOrders",
        "PollingService.nonCoreOrders",
        "PollingService.getPollingStrategy",
        "PushService.polling",
        "IMChatService.getChatInfo",
        "IMChatService.getImInfo",
        "ShopMessageService.pollingNotifyV2",
        "ShopMessageService.getShopMessageList",
        "ShopMessageService.getMessageTabShowStyle",
        "SceneManageService.getSpaceInfoBySpaceCodes",
        "OrderWebService.queryInProcessOrders",
        "OrderWebService.queryHeadDataByInProcessQueryType",
        "OrderWebService.queryTabDataForWeb",
        "OrderWebService.countMenuOrder",
        "OrderWebService.getWebClientSettings",
        "ShopQueryService.queryAdBanner",
        "ShopQueryService.queryExceptionInfo",
        "ShopQueryService.queryDataByTab",
        "ShopQueryService.hitAutoMealRightGray",
        "ShopSettingService.getOrderSetting",
        "ShopSettingService.getRemindCookTimeSetting",
        "OrderSettingService.checkSettingStatus",
        "BusinessAssistService.getOrderProcessTips",
        "DeliveryClaimService.getOrderClaimTips",
        "RpcStrategyTriggerService.getOfflineMessage",
        "GrayService.inGray",
        "GrayService.getGrayStatusByKeys",
        "GrayService.getRestaurantAttribute",
        "GrayService.grayMenuAppealCompensation2Gray",
        "GrayNcpService.isInGray",
        "GrayControlService.getConfigV2",
        "ABTestService.getResult",
        "AlscTagService.queryTagsByTagId",
        "AssistantEntranceService.getAssistantEntranceInfo",
        "AssistantEntranceService.getValidPages",
        "AuthCenterService.getToken",
        "CrmOpenService.checkCrmEntry",
        "DownloadDataService.queryHistoryList",
        "ExportRatingTaskService.queryExportRatingTasks",
        "FoodService2.getFoodTabWithType",
        "FoodService2.getPcFoodManageButton",
        "FoodService2.queryCategoryWithFoodFilter",
        "KeeperService.getKeeper",
        "PackageItemService.getRecommendPackageMigradeList",
        "PersonalCustomerManageService.personalCustomerGray",
        "ShopService.queryAgreement",
        "queryShop.getShopView",
        "shopRating.countNewShopRating"
    ],
    "ignore_api_prefixes": [
        "xtop.shop.shopBusinessQueryTop.",
        "xtop.arena.",
        "xtop.napos.",
        "xtop.pts.",
        "xtop.ebot."
    ],
    "ignore_urls": [
        "/log/", "/track/", "/beacon/", "/analytics/", "/collect",
        "report.meituan.com", "sentry", "aegis", "arms-retcode",
        "/pv", "/webdfpid", "/fingerprint/", "/bio/info/report",
        "spiderindefence", "yoda_seed", "sdk_ver",
        ".png", ".jpg", ".gif", ".css", ".woff", ".ttf"
    ]
}

# ========== Action parsing ==========

def parse_body(body_str):
    """Parse body JSON string, return dict or empty dict"""
    if not body_str:
        return {}
    try:
        return json.loads(body_str) if isinstance(body_str, str) else body_str
    except:
        return {}

def extract_shop_id(body):
    """Extract shopId from parsed body"""
    if not isinstance(body, dict):
        return ""
    metas = body.get("metas", {})
    if metas and metas.get("shopId"):
        return str(metas["shopId"])
    params = body.get("params", {})
    for v in params.values():
        if isinstance(v, dict) and v.get("shopId"):
            return str(v["shopId"])
    return ""

def extract_item_id_from_body(api_method, body):
    """Server-side extraction of item_id from body (fallback when extension fails)"""
    if not isinstance(body, dict):
        return ""
    params = body.get("params", {})

    # updateGoodsAttr
    if "updateGoodsAttr" in api_method:
        attr = params.get("updateGoodsAttr", {})
        if isinstance(attr, dict) and attr.get("itemId"):
            return str(attr["itemId"])

    # batchUpdateFood
    if "batchUpdateFood" in api_method:
        req = params.get("request", {})
        ids = req.get("itemGlobalIds", [])
        if ids:
            return ",".join(str(i) for i in ids)

    # updateFood / generic
    for key in ("food", "request"):
        food = params.get(key, {})
        if isinstance(food, dict):
            for id_key in ("id", "itemId", "itemGlobalId"):
                if food.get(id_key):
                    return str(food[id_key])

    return ""

def extract_item_name_from_body(api_method, body):
    """Server-side extraction of item_name from body"""
    if not isinstance(body, dict):
        return ""
    params = body.get("params", {})

    if "updateGoodsAttr" in api_method:
        attr = params.get("updateGoodsAttr", {})
        return attr.get("name", "")

    for key in ("food", "request"):
        food = params.get(key, {})
        if isinstance(food, dict):
            return food.get("name", food.get("foodName", ""))

    return ""

def parse_action(api_method, body, conn=None):
    """Parse API + body into (action_type, action_detail)
    conn: optional DB connection for looking up food names from cache
    """
    params = body.get("params", {}) if isinstance(body, dict) else {}

    # batchUpdateFood - 上架/下架/批量修改
    if "batchUpdateFood" in api_method:
        req = params.get("request", {})
        is_on = req.get("isOnShelf")
        ids = req.get("itemGlobalIds", [])
        # Look up actual food names from cache
        names = []
        if conn and ids:
            for gid in ids:
                cached = conn.execute("SELECT name FROM food_cache WHERE item_key=?", (str(gid),)).fetchone()
                if cached and cached["name"]:
                    names.append(cached["name"])
        name_str = ", ".join(names) if names else f"{len(ids)}个菜品"
        if is_on is True:
            return "上架", name_str
        elif is_on is False:
            return "下架", name_str
        op_type = req.get("operationType", "")
        return "批量修改", name_str

    # updateGoodsAttr
    if "updateGoodsAttr" in api_method:
        attr = params.get("updateGoodsAttr", {})
        name = attr.get("name", "")
        specs = attr.get("sfoodSpecs", [])
        if specs:
            parts = []
            for s in specs:
                sp = []
                if s.get("price") is not None:
                    sp.append(f"价格:{s['price']}")
                if s.get("stock") is not None:
                    sp.append(f"库存:{s['stock']}")
                if sp:
                    parts.append(" ".join(sp))
            detail = f"{name} | {'; '.join(parts)}" if parts else name
            return "改规格/价格", detail
        elif name:
            return "改名", name
        return "改属性", json.dumps(attr, ensure_ascii=False)[:200]

    # updateFood
    if "updateFood" in api_method and "batch" not in api_method.lower():
        food = params.get("food", params.get("request", {}))
        name = ""
        if isinstance(food, dict):
            name = food.get("name", food.get("foodName", ""))
        return "修改菜品", name

    # createFood
    if "createFood" in api_method:
        food = params.get("food", params.get("request", {}))
        name = food.get("name", "") if isinstance(food, dict) else ""
        return "新建菜品", name

    # deleteFood
    if "deleteFood" in api_method:
        return "删除菜品", ""

    # Category
    if "Category" in api_method:
        cat = params.get("category", params.get("request", {}))
        name = cat.get("name", cat.get("categoryName", "")) if isinstance(cat, dict) else ""
        if "create" in api_method.lower():
            return "新建分类", name
        if "update" in api_method.lower():
            return "修改分类", name
        if "delete" in api_method.lower():
            return "删除分类", name
        if "sort" in api_method.lower():
            return "排序分类", ""

    # Activity
    if "Activity" in api_method or "activity" in api_method:
        if "create" in api_method.lower():
            return "创建活动", ""
        if "update" in api_method.lower():
            return "修改活动", ""
        if "delete" in api_method.lower() or "close" in api_method.lower():
            return "关闭活动", ""

    # replyRating
    if "replyRating" in api_method or "reply" in api_method.lower():
        content = ""
        for v in params.values():
            if isinstance(v, dict) and v.get("replyContent"):
                content = v["replyContent"][:50]
                break
            if isinstance(v, str) and len(v) > 5:
                content = v[:50]
                break
        return "回复评价", content

    # Shop info
    if "updateShop" in api_method or "ShopService.update" in api_method:
        return "修改店铺信息", ""

    # Fallback
    method_name = api_method.split(".")[-1] if "." in api_method else api_method
    return method_name, ""

def build_before_after(action_type, body, before_snapshot):
    """Build human-readable before -> after diff"""
    if not before_snapshot:
        return ""

    try:
        before = json.loads(before_snapshot) if isinstance(before_snapshot, str) else before_snapshot
    except:
        return ""

    params = body.get("params", {}) if isinstance(body, dict) else {}
    diffs = []

    # Single item before (from food cache or previous log)
    if isinstance(before, dict) and "name" in before:
        # updateGoodsAttr with name change
        if action_type == "改名":
            attr = params.get("updateGoodsAttr", {})
            new_name = attr.get("name", "")
            old_name = before.get("name", "")
            if new_name and old_name and new_name != old_name:
                diffs.append(f"名称: {old_name} -> {new_name}")
            elif new_name:
                diffs.append(f"名称 -> {new_name}")

        # Price change
        if action_type in ("改规格/价格",):
            attr = params.get("updateGoodsAttr", {})
            new_specs = attr.get("sfoodSpecs", [])
            old_specs = before.get("specs", [])
            old_price_map = {s.get("id"): s.get("price") for s in old_specs if s.get("id")}
            for ns in new_specs:
                sid = ns.get("id")
                new_price = ns.get("price")
                old_price = old_price_map.get(sid)
                if old_price is not None and new_price is not None and old_price != new_price:
                    diffs.append(f"价格: {old_price} -> {new_price}")

    # Batch items (multiple before snapshots keyed by globalId)
    if isinstance(before, dict) and all(isinstance(v, dict) for v in before.values()):
        names = [v.get("name", "?") for v in before.values() if v.get("name")]
        if names:
            diffs.append(f"菜品: {', '.join(names[:5])}")

    return " | ".join(diffs)

# ========== API ==========

@app.route("/api/config")
def get_config():
    return jsonify(load_config())

@app.route("/api/config", methods=["POST"])
def update_config():
    cfg = request.get_json(silent=True)
    if not cfg:
        return jsonify({"error": "no data"}), 400
    save_config(cfg)
    return jsonify({"ok": True})

@app.route("/api/logs", methods=["POST"])
def receive_logs():
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "no data"}), 400

    operator = data.get("operator", "unknown")
    logs = data.get("logs", [])
    if not logs:
        return jsonify({"saved": 0})

    conn = get_db()
    saved = 0
    for log in logs:
        url = log.get("url", "")
        platform = "eleme" if "ele.me" in url or "eleme" in url else "meituan" if "meituan" in url else "other"

        # Full body (v2: no truncation; v1 compat: bodySnippet)
        body_str = log.get("body") or log.get("bodySnippet", "")
        body = parse_body(body_str)

        # Structured fields - prefer from extension, fallback to body parsing
        shop_id = log.get("shopId", "") or extract_shop_id(body)
        shop_name = log.get("shopName", "")
        item_id = log.get("itemId", "")
        item_name = log.get("itemName", "")
        before_snapshot = log.get("beforeSnapshot", "")

        # Lookup shop name from cache if not provided
        if shop_id and not shop_name:
            cached_shop = conn.execute("SELECT shop_name FROM shop_cache WHERE shop_id=?", (shop_id,)).fetchone()
            if cached_shop:
                shop_name = cached_shop["shop_name"]

        # Save shop name to cache
        if shop_id and shop_name:
            conn.execute(
                "INSERT OR REPLACE INTO shop_cache (shop_id, shop_name, platform, updated_at) VALUES (?,?,?,?)",
                (shop_id, shop_name, platform, datetime.now().isoformat())
            )

        api_method = log.get("apiMethod", "")

        # Server-side extraction from body as fallback
        if not item_id:
            item_id = extract_item_id_from_body(api_method, body)
        if not item_name:
            item_name = extract_item_name_from_body(api_method, body)

        # ALWAYS use food_cache as the source of truth for before_snapshot
        # This fixes the bug where extension sends stale cache data
        if item_id:
            cache_before = {}
            for iid in item_id.split(","):
                iid = iid.strip()
                if not iid:
                    continue
                cached = conn.execute("SELECT name, price, specs FROM food_cache WHERE item_key=?", (iid,)).fetchone()
                if cached:
                    if not item_name:
                        item_name = cached["name"] if not item_name else item_name
                    cache_before[iid] = {
                        "name": cached["name"] or "",
                        "price": cached["price"] or 0,
                    }
                    # Parse specs from JSON if stored
                    try:
                        specs_data = json.loads(cached["specs"]) if cached["specs"] else {}
                        if isinstance(specs_data, dict):
                            cache_before[iid].update({k: v for k, v in specs_data.items() if k in ("status", "category", "image")})
                    except:
                        pass
            if cache_before:
                # Use food_cache as before, overriding extension's potentially stale data
                if len(cache_before) == 1:
                    before_snapshot = json.dumps(list(cache_before.values())[0], ensure_ascii=False)
                else:
                    before_snapshot = json.dumps(cache_before, ensure_ascii=False)

        # If still no item_name, try food_cache by item_id
        if item_id and not item_name:
            names = []
            for iid in item_id.split(","):
                cached = conn.execute("SELECT name FROM food_cache WHERE item_key=?", (iid.strip(),)).fetchone()
                if cached and cached["name"]:
                    names.append(cached["name"])
            if names:
                item_name = ", ".join(names)

        action_type, action_detail = parse_action(api_method, body, conn)

        # Build diff string and append to action_detail
        diff_str = build_before_after(action_type, body, before_snapshot)
        if diff_str:
            action_detail = f"{action_detail} [{diff_str}]" if action_detail else diff_str

        # Update food_cache with NEW state after modification
        # This ensures next modification picks up the correct "before" value
        if item_id:
            for i, iid in enumerate(item_id.split(",")):
                iid = iid.strip()
                if not iid:
                    continue
                # Get existing cache entry to preserve fields we're not changing
                existing = conn.execute("SELECT specs FROM food_cache WHERE item_key=?", (iid,)).fetchone()
                existing_data = {}
                if existing and existing["specs"]:
                    try:
                        existing_data = json.loads(existing["specs"])
                    except:
                        pass

                # Determine the new name
                names = item_name.split(",") if item_name else []
                new_name = names[i].strip() if i < len(names) else (names[-1].strip() if names else "")
                if not new_name and existing_data.get("name"):
                    new_name = existing_data["name"]

                # Determine new price
                new_price = existing_data.get("price", 0)
                if action_type == "改规格/价格":
                    attr = (body.get("params", {}) if isinstance(body, dict) else {}).get("updateGoodsAttr", {})
                    new_specs = attr.get("sfoodSpecs", [])
                    if new_specs and new_specs[0].get("price") is not None:
                        new_price = new_specs[0]["price"]

                # Update status for shelf operations
                new_status = existing_data.get("status", "")
                if action_type == "上架":
                    new_status = "上架"
                elif action_type == "下架":
                    new_status = "下架"

                # Build updated cache data
                cache_data = {**existing_data, "name": new_name, "price": new_price, "status": new_status}

                conn.execute(
                    "INSERT OR REPLACE INTO food_cache (item_key, item_id, shop_id, name, price, specs, updated_at) VALUES (?,?,?,?,?,?,?)",
                    (iid, iid, shop_id, new_name, new_price,
                     json.dumps(cache_data, ensure_ascii=False), datetime.now().isoformat())
                )

        conn.execute(
            """INSERT INTO logs (operator, timestamp, api_method, url, body_full, platform,
                shop_id, shop_name, tab_id, item_id, item_name, action_type, action_detail, before_snapshot)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (operator, log.get("timestamp", ""), api_method, url[:500], body_str,
             platform, shop_id, shop_name, log.get("tab_id", 0), item_id, item_name,
             action_type, action_detail, before_snapshot)
        )
        saved += 1
    conn.commit()
    conn.close()
    return jsonify({"saved": saved})

@app.route("/api/logs", methods=["GET"])
def query_logs():
    operator = request.args.get("operator", "")
    limit = int(request.args.get("limit", 200))
    conn = get_db()
    if operator:
        rows = conn.execute("SELECT * FROM logs WHERE operator=? ORDER BY id DESC LIMIT ?", (operator, limit)).fetchall()
    else:
        rows = conn.execute("SELECT * FROM logs ORDER BY id DESC LIMIT ?", (limit,)).fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

@app.route("/api/cache/sync", methods=["POST"])
def sync_cache():
    """Receive food/shop cache from extension (passive capture from API responses)"""
    data = request.get_json(silent=True)
    if not data:
        return jsonify({"error": "no data"}), 400

    cache_type = data.get("type", "")
    items = data.get("data", [])
    if not items:
        return jsonify({"saved": 0})

    conn = get_db()
    saved = 0
    now = datetime.now().isoformat()

    if cache_type == "foods":
        for f in items:
            item_id = str(f.get("itemId", ""))
            item_global_id = str(f.get("itemGlobalId", ""))
            shop_id = str(f.get("shopId", ""))
            name = f.get("name", "")
            price = f.get("price", 0)

            # Build rich cache data
            cache_data = json.dumps({
                "name": name, "price": price,
                "image": f.get("image", ""),
                "description": f.get("description", ""),
                "monthlySales": f.get("monthlySales", 0),
                "status": "上架" if f.get("isOnShelf", True) else "下架",
                "category": f.get("categoryName", ""),
                "specs": f.get("specs", []),
            }, ensure_ascii=False)

            for key in [item_id, item_global_id]:
                if key and key != "None" and key != "":
                    conn.execute(
                        "INSERT OR REPLACE INTO food_cache (item_key, item_id, shop_id, name, price, specs, updated_at) VALUES (?,?,?,?,?,?,?)",
                        (key, item_id, shop_id, name, price, cache_data, now)
                    )
                    saved += 1

            # Also update food_snapshot if exists
            if item_id:
                existing = conn.execute("SELECT id FROM food_snapshot WHERE item_id=? AND shop_id=?", (item_id, shop_id)).fetchone()
                if not existing:
                    conn.execute(
                        """INSERT INTO food_snapshot
                        (shop_id, platform, item_id, item_global_id, category_name, name, price,
                         image_url, specs, status, monthly_sales, description, snapshot_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (shop_id, "eleme", item_id, item_global_id, f.get("categoryName", ""),
                         name, price, f.get("image", ""),
                         json.dumps(f.get("specs", []), ensure_ascii=False),
                         "上架" if f.get("isOnShelf", True) else "下架",
                         f.get("monthlySales", 0), f.get("description", ""), now)
                    )

    elif cache_type == "shops":
        for s in items:
            shop_id = str(s.get("shopId", ""))
            shop_name = s.get("shopName", "")
            if shop_id and shop_name:
                conn.execute(
                    "INSERT OR REPLACE INTO shop_cache (shop_id, shop_name, platform, updated_at) VALUES (?,?,?,?)",
                    (shop_id, shop_name, "eleme", now)
                )
                saved += 1

    conn.commit()
    conn.close()
    print(f"[cache sync] {cache_type}: {saved} items")
    return jsonify({"saved": saved})

@app.route("/api/food_cache", methods=["GET"])
def get_food_cache():
    conn = get_db()
    rows = conn.execute("SELECT * FROM food_cache ORDER BY updated_at DESC LIMIT 500").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])

# ========== Dashboard ==========

PAGE_HTML = """<!DOCTYPE html>
<html><head>
<meta charset="utf-8"><title>Ops Logger</title>
<style>
  body { font-family: -apple-system, sans-serif; margin: 20px; background: #f5f5f5; color: #333; }
  h1 { font-size: 20px; margin-bottom: 0; }
  .stats { display: flex; gap: 16px; margin: 12px 0; }
  .stat { background: white; padding: 10px 18px; border-radius: 8px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); }
  .stat .n { font-size: 22px; font-weight: bold; color: #e94560; }
  .stat .l { font-size: 11px; color: #999; }
  .filters { margin: 12px 0; display: flex; gap: 8px; align-items: center; }
  select, input { padding: 6px 10px; border: 1px solid #ddd; border-radius: 4px; font-size: 13px; }
  .btn { background: #e94560; color: white; border: none; padding: 6px 14px; border-radius: 4px; cursor: pointer; font-size: 13px; }
  .list { display: flex; flex-direction: column; gap: 6px; }
  .card { background: white; border-radius: 8px; padding: 12px 14px; box-shadow: 0 1px 3px rgba(0,0,0,0.08); border-left: 4px solid #e94560; }
  .card .top { display: flex; justify-content: space-between; align-items: center; margin-bottom: 4px; }
  .card .action { font-size: 14px; font-weight: 600; color: #222; }
  .card .time { font-size: 11px; color: #aaa; }
  .card .meta { font-size: 12px; color: #888; margin-top: 2px; }
  .card .item-info { font-size: 13px; color: #333; margin-top: 4px; }
  .card .diff { font-size: 12px; color: #0066cc; margin-top: 3px; font-style: italic; }
  .card .detail { font-size: 11px; color: #aaa; margin-top: 4px; word-break: break-all; background: #fafafa; padding: 4px 6px; border-radius: 3px; display: none; max-height: 200px; overflow-y: auto; }
  .card:hover .detail { display: block; }
  .tag { display: inline-block; padding: 1px 6px; border-radius: 3px; font-size: 10px; margin-right: 6px; }
  .tag-eleme { background: #e6f3ff; color: #0066cc; }
  .tag-meituan { background: #fff3e6; color: #cc6600; }
  .tag-other { background: #f0f0f0; color: #666; }
  .act-tag { display: inline-block; padding: 2px 8px; border-radius: 3px; font-size: 11px; font-weight: 600; margin-right: 6px; }
  .act-上架 { background: #e8f5e9; color: #2e7d32; }
  .act-下架 { background: #fce4ec; color: #c62828; }
  .act-改名 { background: #e3f2fd; color: #1565c0; }
  .act-改规格价格, .act-改规格\\/价格 { background: #fff3e0; color: #e65100; }
  .act-修改菜品 { background: #f3e5f5; color: #6a1b9a; }
  .act-新建菜品 { background: #e8f5e9; color: #1b5e20; }
  .act-删除菜品 { background: #fce4ec; color: #b71c1c; }
  .act-回复评价 { background: #e0f7fa; color: #00695c; }
  .empty { text-align: center; color: #bbb; padding: 40px; font-size: 14px; }
</style>
</head><body>
<h1>Ops Logger</h1>
<div class="stats" id="stats"></div>
<div class="filters">
  <select id="fOperator"><option value="">all</option></select>
  <select id="fAction"><option value="">all actions</option></select>
  <input id="fSearch" placeholder="search..." />
  <button class="btn" onclick="load()">refresh</button>
</div>
<div class="list" id="list"></div>
<script>
function esc(s) { return (s||'').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }

function fmtTime(ts) {
  if (!ts) return '';
  const d = new Date(ts);
  const pad = n => String(n).padStart(2, '0');
  return (d.getMonth()+1) + '/' + d.getDate() + ' ' + pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function actClass(t) {
  return 'act-' + (t||'').replace(/[\\/ ]/g, '');
}

async function load() {
  const op = document.getElementById('fOperator').value;
  const actFilter = document.getElementById('fAction').value;
  const search = document.getElementById('fSearch').value.toLowerCase();
  const url = '/api/logs?limit=500' + (op ? '&operator=' + op : '');
  const res = await fetch(url);
  const logs = await res.json();

  const operators = [...new Set(logs.map(l => l.operator).filter(Boolean))];
  const actions = [...new Set(logs.map(l => l.action_type).filter(Boolean))];
  const today = new Date().toISOString().slice(0,10);
  const todayCount = logs.filter(l => l.timestamp && l.timestamp.startsWith(today)).length;

  document.getElementById('stats').innerHTML =
    '<div class="stat"><div class="n">' + logs.length + '</div><div class="l">total</div></div>' +
    '<div class="stat"><div class="n">' + todayCount + '</div><div class="l">today</div></div>' +
    '<div class="stat"><div class="n">' + operators.length + '</div><div class="l">people</div></div>';

  // Populate filters
  const selOp = document.getElementById('fOperator');
  const curOp = selOp.value;
  selOp.innerHTML = '<option value="">all</option>';
  operators.forEach(o => { selOp.innerHTML += '<option value="'+esc(o)+'"'+(o===curOp?' selected':'')+'>'+esc(o)+'</option>'; });

  const selAct = document.getElementById('fAction');
  const curAct = selAct.value;
  selAct.innerHTML = '<option value="">all actions</option>';
  actions.forEach(a => { selAct.innerHTML += '<option value="'+esc(a)+'"'+(a===curAct?' selected':'')+'>'+esc(a)+'</option>'; });

  let filtered = logs;
  if (actFilter) filtered = filtered.filter(l => l.action_type === actFilter);
  if (search) {
    filtered = filtered.filter(l =>
      (l.api_method||'').toLowerCase().includes(search) ||
      (l.item_name||'').toLowerCase().includes(search) ||
      (l.action_detail||'').toLowerCase().includes(search) ||
      (l.operator||'').toLowerCase().includes(search) ||
      (l.shop_id||'').includes(search)
    );
  }

  if (filtered.length === 0) {
    document.getElementById('list').innerHTML = '<div class="empty">no logs</div>';
    return;
  }

  document.getElementById('list').innerHTML = filtered.map(l => {
    const ptag = l.platform === 'eleme' ? 'tag-eleme' : l.platform === 'meituan' ? 'tag-meituan' : 'tag-other';
    const pname = l.platform === 'eleme' ? '饿了么' : l.platform === 'meituan' ? '美团' : l.platform || '';
    const hasItemInfo = l.item_name || l.action_detail;
    const hasDiff = l.action_detail && l.action_detail.includes('->');

    return '<div class="card">' +
      '<div class="top">' +
        '<span class="action"><span class="act-tag ' + actClass(l.action_type) + '">' + esc(l.action_type || l.api_method) + '</span></span>' +
        '<span class="time">' + fmtTime(l.timestamp) + '</span>' +
      '</div>' +
      '<div class="meta">' +
        '<span class="tag ' + ptag + '">' + pname + '</span>' +
        esc(l.operator||'') +
        (l.shop_name ? ' &middot; ' + esc(l.shop_name) : l.shop_id ? ' &middot; 店铺' + esc(l.shop_id) : '') +
      '</div>' +
      (hasItemInfo ? '<div class="item-info">' +
        (l.item_name ? '<b>' + esc(l.item_name) + '</b>' : '') +
        (l.action_detail && l.action_detail !== l.item_name ? ' &mdash; ' + esc(l.action_detail) : '') +
      '</div>' : '') +
      (hasDiff ? '<div class="diff">' + esc(l.action_detail) + '</div>' : '') +
      '<div class="detail">' + esc(l.body_full || l.body_snippet || '') + '</div>' +
    '</div>';
  }).join('');
}
load();
setInterval(load, 15000);
</script>
</body></html>"""

@app.route("/")
def dashboard():
    return render_template_string(PAGE_HTML)

@app.route("/api/extension/version")
def extension_version():
    manifest_path = os.path.join(os.path.dirname(__file__), "manifest.json")
    try:
        with open(manifest_path) as f:
            m = json.load(f)
        return jsonify({"version": m.get("version", "0")})
    except:
        return jsonify({"version": "0"})

@app.route("/health")
def health():
    return jsonify({"status": "ok", "time": datetime.now().isoformat()})

if __name__ == "__main__":
    init_db()
    if not os.path.exists(CONFIG_PATH):
        save_config(DEFAULT_CONFIG)
    app.run(host="0.0.0.0", port=5500, debug=False)
