function fmt(ts) {
  try {
    var d = new Date(ts);
    return (d.getMonth()+1) + '/' + d.getDate() + ' ' +
      String(d.getHours()).padStart(2,'0') + ':' +
      String(d.getMinutes()).padStart(2,'0');
  } catch(e) { return ''; }
}

function actClass(t) {
  return 'act-' + (t||'').replace(/[/ ]/g, '');
}

function describeAction(log) {
  var api = log.apiMethod || '';
  if (api.includes('batchUpdateFood')) {
    try {
      var body = typeof log.body === 'string' ? JSON.parse(log.body) : log.body;
      var req = body && body.params && body.params.request;
      if (req) return req.isOnShelf ? '上架' : '下架';
    } catch(e) {}
    return '批量修改';
  }
  if (api.includes('updateGoodsAttr')) {
    try {
      var body2 = typeof log.body === 'string' ? JSON.parse(log.body) : log.body;
      var attr = body2 && body2.params && body2.params.updateGoodsAttr;
      if (attr && attr.sfoodSpecs) return '改规格/价格';
      if (attr && attr.name) return '改名';
    } catch(e) {}
    return '改属性';
  }
  if (api.includes('updateFood')) return '修改菜品';
  if (api.includes('createFood')) return '新建菜品';
  if (api.includes('deleteFood')) return '删除菜品';
  if (api.includes('Category')) return '修改分类';
  if (api.includes('Activity')) return '修改活动';
  if (api.includes('reply')) return '回复评价';
  if (api.includes('updateShop')) return '修改店铺';
  var parts = api.split('.');
  return parts[parts.length - 1] || '操作';
}

function init() {
  chrome.runtime.sendMessage({ type: 'OPS_GET_STATE' }, function(state) {
    if (chrome.runtime.lastError || !state) {
      setTimeout(init, 300);
      return;
    }
    if (!state.operator) {
      document.getElementById('setup').style.display = 'block';
      document.getElementById('main').style.display = 'none';
    } else {
      document.getElementById('setup').style.display = 'none';
      document.getElementById('main').style.display = 'block';
      document.getElementById('verLabel').textContent = 'v' + state.version;

      var statusEl = document.getElementById('syncStatus');
      if (state.unpushed > 0) {
        statusEl.textContent = state.unpushed + ' pending';
        statusEl.className = 'status status-pending';
      } else {
        statusEl.textContent = 'synced';
        statusEl.className = 'status status-ok';
      }

      document.getElementById('info').innerHTML =
        '<div class="chip"><b>' + state.operator + '</b></div>' +
        '<div class="chip"><b>' + state.logCount + '</b> logs</div>' +
        '<div class="chip">cache: <b>' + (state.foodCacheSize || 0) + '</b> foods</div>';

      renderLogs(state.recentLogs || []);
    }
  });
}

function renderLogs(logs) {
  var el = document.getElementById('logs');
  if (!logs.length) {
    el.innerHTML = '<div class="empty">还没有操作记录</div>';
    return;
  }

  el.innerHTML = logs.map(function(l) {
    var action = describeAction(l);
    var shop = l.shopName || (l.shopId ? '店铺' + l.shopId : '');
    var item = l.itemName || l.itemId || '';

    return '<div class="log">' +
      '<div class="row1">' +
        '<span class="act ' + actClass(action) + '">' + action + '</span>' +
        '<span class="time">' + fmt(l.timestamp) + '</span>' +
      '</div>' +
      '<div class="row2">' +
        (shop ? '<span class="shop">' + shop + '</span> ' : '') +
        (item ? '<span class="item">' + item + '</span>' : '') +
      '</div>' +
    '</div>';
  }).join('');
}

document.addEventListener('DOMContentLoaded', function() {
  init();

  document.getElementById('okBtn').addEventListener('click', function() {
    var name = document.getElementById('nameInput').value.trim();
    if (!name) return;
    chrome.runtime.sendMessage({ type: 'OPS_SET_OPERATOR', name: name }, function() {
      if (!chrome.runtime.lastError) init();
    });
  });

  document.getElementById('nameInput').addEventListener('keydown', function(e) {
    if (e.key === 'Enter') document.getElementById('okBtn').click();
  });

  document.getElementById('btnClear').addEventListener('click', function() {
    if (!confirm('清空本地所有记录？')) return;
    chrome.storage.local.set({ ops_logs: [] }, function() {
      chrome.action.setBadgeText({ text: '' });
      init();
    });
  });

  document.getElementById('btnExport').addEventListener('click', function() {
    chrome.storage.local.get('ops_logs', function(data) {
      var blob = new Blob([JSON.stringify(data.ops_logs || [], null, 2)], { type: 'application/json' });
      var a = document.createElement('a');
      a.href = URL.createObjectURL(blob);
      a.download = 'ops_logs_' + new Date().toISOString().slice(0, 10) + '.json';
      a.click();
    });
  });

  // Auto refresh popup every 5s
  setInterval(init, 5000);
});
